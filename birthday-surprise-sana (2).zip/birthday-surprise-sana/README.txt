# A Little Birthday Surprise for Sana ♡

A mobile-friendly scrapbook birthday website built with plain HTML, CSS, and JavaScript.

## Project files
- `index.html` — page content
- `style.css` — scrapbook look and responsive layout
- `script.js` — photo sequence, captions, navigation, slideshow, confetti, and music controls
- `images/1.svg` to `images/8.svg` — temporary placeholder pictures
- `music.mp3` — add your own music file here (not included)

## Add your own photos
1. Choose 5–8 photos and crop them vertically/square-ish for best results.
2. Replace `images/1.svg` through `images/8.svg` with your photos, or add JPG/PNG files and edit the `image` values near the top of `script.js`.
3. If you use JPG files, for example, change `image: "images/1.svg"` to `image: "images/1.jpg"` for each memory.
4. Edit the `label` and `caption` text in `script.js` to match your memories.
5. You can remove any memory objects from the `memories` array if you want fewer photos.

## Add music
Place a music file you have permission to use in this folder and name it `music.mp3`.
The site tries to start music when the surprise is opened, but some mobile browsers may require the visitor to tap the music button. Browsers often block autoplay before a user gesture.

## Run locally
- Open this folder in VS Code.
- If you have the Live Server extension, right-click `index.html` and choose **Open with Live Server**.
- Or double-click `index.html` to open it in your browser.

## Free hosting with GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a **public** repository named `birthday-surprise`.
3. Upload `index.html`, `style.css`, `script.js`, the complete `images` folder, and `music.mp3` if you add it.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Select branch `main` and folder `/(root)`, then save.
7. Wait a minute or two. GitHub Pages will show a public URL similar to:
   `https://YOUR-USERNAME.github.io/birthday-surprise/`
8. Open that URL on your phone and test all photos, buttons, and music.

Note: A public GitHub Pages site can be visited by anyone who has the URL. Don't publish private or sensitive pictures if you aren't comfortable with that.

## Make the QR code
1. Copy the exact live GitHub Pages URL.
2. Paste it into a QR generator such as https://www.qr-code-generator.com/ or https://qr.io/.
3. Download the QR code and test it with your phone camera before printing.
4. Print it on a birthday card or gift tag. Keep the URL text as a backup in case the QR code is damaged.

## How the slideshow works
- Tap the arrow to reveal each next memory.
- Double-click the photo (or double-tap on a touchscreen) to toggle automatic slideshow mode.
- The final photo leads to the birthday letter and confetti.
- The music button toggles the background audio.

## Personalization ideas
Replace the generic captions with shared jokes, nicknames, trips, college memories, or little things you appreciate about Sana.
